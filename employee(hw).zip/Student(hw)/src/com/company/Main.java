package com.company;

public class Main extends student{

    public static void main(String[] args) {


        student s1 = new student();
        student s2 = new student();
        student s3 = new student();




        // creating object using constructor
//using set method setting Student's attribute
        s1.setEid(12031);
        s1.setSname("Anna");
        s1.setSalary(22000);
        s1.setEmail("anna@g.com");
        s1.setDepartment("IT");

        System.out.println("=======================");

        s2.setEid(12033);
        s2.setSname("billy");
        s2.setSalary(24000);
        s2.setEmail("bily@g.com");
        s2.setDepartment("HR");

        s3.setEid(12032);
        s3.setSname("john");
        s3.setSalary(21000);
        s3.setEmail("john@g.com");
        s3.setDepartment("EXE");




// Display Student information using String -> s1
        System.out.println("Employee ID : "+s1.getEid());
        System.out.println("employee Name : "+s1.getSname());
        System.out.println("Employee Salary : "+s1.getSalary());
        System.out.println("Email : "+s1.getEmail());
        System.out.println("Department : " + s1.getDepartment());

        System.out.println("=======================");

        System.out.println("Employee ID : "+s2.getEid());
        System.out.println("employee Name : "+s2.getSname());
        System.out.println("Employee Salary : "+s2.getSalary());
        System.out.println("Email : "+s2.getEmail());
        System.out.println("Department : " + s2.getDepartment());

        System.out.println("=======================");


        System.out.println("Employee ID : "+s3.getEid());
        System.out.println("employee Name : "+s3.getSname());
        System.out.println("Employee Salary : "+s3.getSalary());
        System.out.println("Email : "+s3.getEmail());
        System.out.println("Department : " + s3.getDepartment());
    }
}



