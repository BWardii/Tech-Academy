package com.company;

public class student {


    int sid;
    String sname;
    String email;
    String department;
    double score;
    // methods
    public int getEid() {
        return sid;
    }
    public void setEid(int sid) {
        this.sid = sid;
    }


    public String getEmail(){
        return email;
    }
    public void setEmail(String email){
        this.email = email;

    }


    public String getDepartment(){
        return department;
    }
    public void setDepartment(String department){
        this.department = department;

    }



    public String getSname() {
        return sname;
    }
    public void setSname(String sname) {
        this.sname = sname;
    }
    public double getSalary() {
        return score;
    }
    public void setSalary(double score) {
        this.score = score;
    }

}
